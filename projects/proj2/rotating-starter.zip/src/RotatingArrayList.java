import java.util.Arrays;

public class RotatingArrayList<E> {

    private E[] data;  // this is where we store the elements of the array
    private int size;    // this is the size of the array from the user's perspective
    private int offset;  // index of the "zero'th" element of the array, used for rotating
    // should always stay between 0 and size-1

    /**
     * Creates a new, empty list.
     */
    @SuppressWarnings("unchecked")
    public RotatingArrayList() {
        // We need to reserve some capacity in our data array for new elements to be added.
        // default constructor
        // We need to reserve some capacity in our data array for new elements to be added.
        data = (E[])(new Object[3]);  // reserves 3 spots in the data array for us to use
        size = 0;
        offset = 0;
    }

    /** Returns a String representation of this list.  The returned string should
     * have all the elements of the list between square brackets, like this:
     * [ 10 20 30 40 ], or something similar.
     */
    public String toString() {
        return "";  // Fill in this method.
    }

    /**
     * Returns the size of this list (from the user's perspective).
     */
    public int size() {
        return 0; // Fill in this method.
    }


    /**
     * Returns the element at index [pos] in the list.  You may assume pos
     * is a valid index in the list.
     */
    public E get(int pos) {
        return null; // Fill in this method.
    }


    /**
     * Sets the element at index [pos] in the list to the given value.  You may assume pos
     * is a valid index in the list.
     */
    public void set(int pos, E value) {
        // Fill in this method.
    }

    /**
     * Rotates the elements in the list one spot to the right (from the user's
     * perspective).  Should not actually move any element's from the programmer's
     * perspective.
     */
    public void rotateRight() {
        // Fill in this method.
    }

    /**
     * Rotates the elements in the list one spot to the left (from the user's
     * perspective).  Should not actually move any element's from the programmer's
     * perspective.
     */
    public void rotateLeft() {
        // Fill in this method.
    }

    /**
     * Returns true if these two RotatingArrayLists are equal from the user's perspective.
     * Note that the underlying arrays may not be identical - you must take offset into account.
     */
    public boolean equals(Object o) {
        return false; // Fill in this method.
    }

    /**
     * Appends a new value to the end of this list from the user's perspective.
     * Because of the offset, the "end" of the list from the user's perspective may not
     * match the actual end of the array.
     */
    public void append(E value) {  // append should add an element to the "end" of the list
        // Fill in this method.
    }

    /**
     * Prepends a new value to the front of this list from the user's perspective.
     * Because of the offset, the "front" of the list from the user's perspective may not
     * match the actual front of the array.
     */
    public void prepend(E value) {  // adds an element to beginning of the list (always index 0)
        // Fill in this method.
    }

    /**
     * Removes the first value in the list from the user's perspective.  Other values shift
     * to the left to fill in the "gap" at index 0.
     * Because of the offset, the value you are removing from the list may not actually
     * be at true index 0.
     */
    public void removeFirst() {
        // Fill in this method.
    }

    /**
     * Removes the last value in the list from the user's perspective.  Nothing shifts
     * from the user's perspective, though shifting might actually be required.
     * Because of the offset, the value you are removing from the list may not actually
     * be at true index size-1.
     */
    public void removeLast() {
        // Fill in this method.
    }

    /**
     * Expands the data[] array by creating a new array of a bigger size than the existing one,
     * and copying everything from the old array into the new array.
     */

    @SuppressWarnings("unchecked")
    private void expand() {
        E[] newdata = (E[])(new Object[data.length + 3]);
        // copy everything from data -> newdata
        for (int i = 0; i < data.length; i++) {
            newdata[i] = data[i];
        }
        data = newdata;
    }
}
