public class RotatingArrayListTester {
    public static void main(String[] args) {

        // Write your tests here.  You will probably want to
        // write separate test functions and call them here.

    }
}
