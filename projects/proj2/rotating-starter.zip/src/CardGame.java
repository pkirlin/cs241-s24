import java.util.Scanner;
import java.util.concurrent.ThreadLocalRandom;

public class CardGame {

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        // Write your game here.  Add any functions you want.

    }

}
