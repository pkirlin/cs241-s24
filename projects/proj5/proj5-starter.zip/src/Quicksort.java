import java.util.ArrayList;
import java.util.Comparator;

public class Quicksort {

    public static <E> void quicksort(ArrayList<E> arrayList, Comparator<E> comparator)
    {
        quicksort(arrayList, comparator, 0, arrayList.size() - 1);
    }

    private static <E> void quicksort(ArrayList<E> arrayList, Comparator<E> comparator, int first, int last)
    {
        if (first < last) {
            int pivIndex = partition(arrayList, comparator, first, last);
            quicksort(arrayList, comparator, first, pivIndex - 1);
            quicksort(arrayList, comparator, pivIndex + 1, last);
        }
    }

    private static <E> int partition(ArrayList<E> arrayList, Comparator<E> comparator, int first, int last)
    {
        // Your code here.
        return 0; // remove this line when you start coding.
    }
}
