import java.util.ArrayList;
import java.util.Scanner;

public class LargeIntTester {
    public static void main(String args[]) {
        //testConstructors();
        //testAdd();
        //testEquals();
        //testCompareTo();
        //testMultiply();
        //testSorting();
    }

    /*
    public static void testSorting() {
        ArrayList<LargeInt> randomNumbers = new ArrayList<>();
        for (int x = 0; x < 10; x++) {
            randomNumbers.add(new LargeInt((int)(Math.random() * 100000)));
        }
        randomNumbers.sort(null);  // null means use the built-in compareTo() method
        System.out.println(randomNumbers);
    } */

}
